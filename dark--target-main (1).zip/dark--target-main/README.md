<div align="center">
</div>
<div align ="center"> 
<i><b> <a href="https://www.facebook.com/Dark.hacker.bd2015">
 DARK HAVKE BD</a><br>
 </b><h4>FACEBOOK TARGET ID HACK </h4></i>

</div>
<br>
<h3>AUTHER</h3>
<p align="center">
<a href="https://github.com/dark-hacker-bd/"><img title="Github" src=""></a> </p>

### FACEBOOK :
<p align="center"> 
<a href="https://www.facebook.com/dark.hacker.bd.dark.boy"><img title="FaceBook" src=" VIRUS-lightgrey?style=for-the-badge&logo=facebook"></a>
</p>


#### TESTED :
***YOU CAN USE IT ON ANY TERMINUL***

## INSTALLATION ON TERMUX :

* `apt-get update -y`
* `apt-get upgrade -y`
* `pkg install git -y`
* `pkg insall python -y`
* `pip install mechanize`
* `pip install requests`
* `git clone https://github.com/dark-hacker-bd/dark--target`
* `cd dark--target`
* `ls`
## INSTALLATION ON KALI :
* `apt-get update -y`
* `apt-get upgrade -y`
* `sudo apt install git -y`
* `sudo apt insall python -y`
* `pip install mechanize`
* `pip install requests`
* `git clone https://github.com/dark-hacker-bd/dark--target`
* `cd dark--target`
* `ls`
## ONE CLICK INSTALLATION TERMUX :
* `apt-get update -y && apt-get upgrade -y &&  pkg install git -y && git clone https://github.com/dark-hacker-bd/dark--target && pip install requests && pip install mechanize && cd dark--target `


## FOR RUN TOOL :
* `cd dark--target`
* `unzip dark-target.zip`
* `need password for unzip`
* `python dark-target.py -t (target id) -w (password list)`
* ` python dark-target.py -t 100001013078780 -w wordlist.txt `
* `press enter`

* `python dark-target.py`



##### DARK HACKER BD

## WARNING : 
***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***









